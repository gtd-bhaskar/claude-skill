# Variable Reference & Config Block

All shortcodes available in the GetTested marketing tool.
Claude uses these exact tokens when generating emails -- never invent new ones.

---

## Config block template

Paste this at the top of `<body>` in every generated email.
Remove lines for variables not used in this email.

```html
<!--
=======================================================
  EMAIL CONFIGURATION
  Edit values here -- changes apply throughout the email
=======================================================

  RECIPIENT:      {{customer_first_name}}       (mail-merge -- set by ESP)

  PRODUCT:        {{product_name}}              = REPLACE
  CTA URL:        {{cta_url}}                   = https://
  CTA LABEL:      {{cta_label}}                 = REPLACE

  BRAND:          {{website_name}}              = GetTested
  WEBSITE:        {{website_url}}               = https://gettested.io
  SUPPORT EMAIL:  {{support_email}}             = support@gettested.io
  YEAR:           {{current_year}}              = 2026
  UNSUBSCRIBE:    {{unsubscribe_url}}            (mail-merge -- set by ESP)

  LOGO:           {{brand_logo}}                (or {{logo_url}})
  HERO IMAGE:     {{hero_image_url}}            = https://  (remove if unused)

  VIDEO URL:      {{video_url}}                 = https://  (remove if unused)
  VIDEO THUMB:    {{video_thumbnail_url}}       = https://  (remove if unused)

  SENDER NAME:    {{sender_name}}               = REPLACE   (remove if no signature)
  SENDER TITLE:   {{sender_title}}              = REPLACE
  SENDER PHOTO:   {{sender_photo_url}}          = https://
  PERSONAL LI:    {{sender_linkedin_personal_url}} = https://linkedin.com/in/REPLACE
  LINKEDIN:       {{social_linkedin_url}}       = https://linkedin.com/company/gettested-io/
  INSTAGRAM:      {{social_instagram_url}}      = https://instagram.com/gettested.io
  FACEBOOK:       {{social_facebook_url}}       = https://facebook.com/gettested.io
  YOUTUBE:        {{social_youtube_url}}        = https://youtube.com/@GetTestedYoutube
  WEBSITE:        {{social_website_url}}        = https://gettested.io

=======================================================
-->
```

---

## Full shortcode reference

### 👤 Customer / Subscriber

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{customer_first_name}}` | Salutation — "Hi {{customer_first_name}}," |
| `{{customer_name}}` | Full name |
| `{{customer_email}}` | Customer email address |
| `{{customer_phone}}` | Phone number |
| `{{first_name}}` | Alias for customer first name |
| `{{last_name}}` | Last name |
| `{{email}}` | Alias for customer email |
| `{{phone_number}}` | Alias for phone |
| `{{subscriber_first_name}}` | First name (subscriber context) |
| `{{subscriber_name}}` | Full name (subscriber context) |
| `{{subscriber_email}}` | Email (subscriber context) |
| `{{recipient_email}}` | Email address of recipient |

**Default salutation:** `Hi {{customer_first_name}},`

---

### 🧾 Account

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{account_first_name}}` | First name from account |
| `{{account_name}}` | Full account name |
| `{{account_email}}` | Account email |
| `{{account_password}}` | Temporary password (welcome / reset emails only) |
| `{{account_gender}}` | Gender |
| `{{account_date_of_birth}}` | Date of birth |
| `{{account_url}}` | Link to account dashboard |

---

### 📦 Order

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{order_id}}` | Order number / reference |
| `{{order_total}}` | Order total (raw) |
| `{{order_total_formatted}}` | Order total with currency symbol |
| `{{currency}}` | Currency code (e.g. GBP, EUR) |
| `{{order_date}}` | Order date (raw) |
| `{{order_date_formatted}}` | Order date (formatted) |
| `{{order_placed_date}}` | Date order was placed |
| `{{order_status}}` | Current order status |
| `{{order_url}}` | Link to order details page |
| `{{order_items_html}}` | HTML block listing all order items |
| `{{order.total}}` | Alias for order total |
| `{{subtotal}}` | Subtotal before tax/shipping |
| `{{vat}}` | VAT amount |
| `{{amount}}` | Payment amount |
| `{{invoice_id}}` | Invoice reference |
| `{{transaction_id}}` | Payment transaction ID |
| `{{reference_number}}` | General reference number |

---

### 🚚 Shipping

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{shipping_address}}` | Delivery address |
| `{{shipping_address_formatted}}` | Delivery address (formatted block) |
| `{{shipping_name}}` | Name on shipping label |
| `{{shipping_cost}}` | Shipping cost |
| `{{tracking_number}}` | Parcel tracking number |
| `{{tracking_url}}` | Link to tracking page |
| `{{carrier}}` | Carrier name (short) |
| `{{carrier_name}}` | Carrier full name |
| `{{carrier_url}}` | Carrier website |
| `{{estimated_delivery}}` | Estimated delivery (raw) |
| `{{estimated_delivery_date}}` | Estimated delivery (formatted) |
| `{{delivery_date}}` | Confirmed delivery date |
| `{{delivery_time}}` | Delivery time window |
| `{{ship_date}}` | Date item shipped |
| `{{shipped_at}}` | Timestamp shipped |
| `{{shipped_date}}` | Alias for ship date |
| `{{packed_date}}` | Date item was packed |

---

### 🛒 Items / Products / Cart

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{product_name}}` | Product or test name |
| `{{product_summary}}` | Short product summary |
| `{{product_short_description}}` | Brief product description |
| `{{product_price}}` | Product price |
| `{{product_image_url}}` | Product image |
| `{{product_url}}` | Product page link |
| `{{items_html}}` | HTML list of all items |
| `{{items_text}}` | Plain text list of items |
| `{{cart_total}}` | Cart total |
| `{{cart_url}}` | Link back to cart |
| `{{cart_items_html}}` | HTML block of cart items |
| `{{this.name}}` | Item name (inside loop) |
| `{{this.price}}` | Item price (inside loop) |
| `{{this.quantity}}` | Item quantity (inside loop) |

---

### 💳 Payment / Refund

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{payment_method}}` | Payment method name |
| `{{payment_display}}` | Payment display string |
| `{{payment_brand}}` | Card brand (Visa, Mastercard) |
| `{{payment_last4}}` | Last 4 digits of card |
| `{{payment_date}}` | Date of payment |
| `{{refund_amount}}` | Refund amount |
| `{{refund_date}}` | Date of refund |
| `{{refund_reference}}` | Refund reference number |
| `{{receipt_url}}` | Link to payment receipt |
| `{{cancellation_date}}` | Date of cancellation |

---

### 🏪 Store / Brand

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{website_name}}` | Brand name — GetTested |
| `{{website_url}}` | Brand website URL |
| `{{website_domain}}` | Domain only (e.g. gettested.io) |
| `{{support_email}}` | Support email address |
| `{{support_url}}` | Support page URL |
| `{{current_year}}` | Copyright year |
| `{{brand_logo}}` | Brand logo image tag or URL |
| `{{logo_url}}` | Logo image URL |
| `{{hero_image_url}}` | Hero / banner image URL |
| `{{privacy_policy_url}}` | Privacy policy page |
| `{{terms_url}}` | Terms and conditions page |

---

### 📅 Appointments / Consultation

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{appointment_date}}` | Appointment date |
| `{{appointment_time}}` | Appointment time |
| `{{service_name}}` | Service or test name |
| `{{service_duration}}` | Duration of service |
| `{{practitioner_name}}` | Practitioner / consultant name |
| `{{consultant_name}}` | Consultant name |
| `{{consultation_url}}` | Link to consultation |
| `{{reschedule_url}}` | Link to reschedule |
| `{{cancel_url}}` | Link to cancel appointment |

---

### 🔬 Lab / Formula / Results

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{results_url}}` | Link to test results page |
| `{{formula_link}}` | Link to personalised formula |
| `{{review_link}}` | Link to leave a review |
| `{{review_url}}` | Alias for review link |

---

### 🔗 Auth / Misc

| Shortcode | Use in email for |
|-----------|-----------------|
| `{{login_url}}` | Login / account access link |
| `{{discount_code}}` | Promotional discount code |
| `{{unsubscribe_url}}` | Unsubscribe link (always in footer) |

---

## Which shortcodes to use in each preset

| Preset | Key shortcodes |
|--------|---------------|
| `marketing` | `{{customer_first_name}}`, `{{product_name}}`, `{{cta_url}}`, `{{unsubscribe_url}}` |
| `flow` | `{{customer_first_name}}`, `{{product_name}}`, `{{order_url}}`, `{{results_url}}` |
| `quiz-result` | `{{customer_first_name}}`, `{{results_url}}`, `{{formula_link}}` |
| `announcement` | `{{customer_first_name}}`, `{{product_name}}`, `{{product_url}}` |
| `re-engagement` | `{{customer_first_name}}`, `{{discount_code}}`, `{{login_url}}` |
| `newsletter` | `{{customer_first_name}}`, `{{website_url}}` |
| Order confirmation | `{{order_id}}`, `{{order_total_formatted}}`, `{{order_items_html}}`, `{{order_url}}` |
| Shipping update | `{{tracking_url}}`, `{{carrier_name}}`, `{{estimated_delivery_date}}` |
| Refund | `{{refund_amount}}`, `{{refund_date}}`, `{{refund_reference}}` |