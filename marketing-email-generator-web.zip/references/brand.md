# Brand Configuration

Claude reads this file first before generating any email.
All values here are pre-filled automatically -- user only provides per-campaign content.

---

## Identity

```
Brand name:      GetTested
Website:         https://gettested.io
Support email:   support@gettested.io
Brand colour:    #0C8097  (teal -- buttons, links, eyebrows)
Secondary:       #36A9CA  (lighter teal -- logo accents)
```

---

## Logo

Two logo variants available (see assets.md for URLs):

| Variant | Asset name | Use when |
|---------|-----------|---------|
| Logo with name | `logo-with-name` | Default -- use in email header |
| Logo icon only | `logo-icon-only` | Compact header or square contexts |

Default header HTML:
```html
<img src="https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/brand%2Fgettested-logo.png"
     alt="GetTested"
     width="160"
     style="display:block; width:160px; height:auto;" />
```

---

## Default sender (used when "with signature" is requested)

```
Name:     Patrik Johansson
Title:    CEO and Founder
Personal LinkedIn: https://www.linkedin.com/in/patrikswe
```

Default photo: `sender-patrik-1` (see assets.md for all 6 photo options)
To use a different photo, reference it by name in the prompt:
  "create a marketing email with signature, use sender-patrik-3"

---

## Social links (corporate)

```
LinkedIn:   https://www.linkedin.com/company/gettested-io/
Instagram:  https://www.instagram.com/gettested.io
Facebook:   https://www.facebook.com/gettested.io
YouTube:    https://www.youtube.com/@GetTestedYoutube
Website:    https://gettested.io
```

---

## Footer defaults

```
Copyright year:  {{current_year}}
Unsubscribe:     {{unsubscribe_url}}  (set by ESP at send time)
Support line:    "Questions? Contact us -- we are here to help."
Sign-off:        "Best of Health,\nGetTested Team"
                 (omit when personal signature block is used)
```