# Copy Writing Guide

## Voice and tone

The brand voice is direct, warm, and science-backed -- like a knowledgeable friend, not a sales pitch.

- **Short sentences.** One idea per sentence. Aim for under 20 words each.
- **Second person always.** "You", "your body", "your results" -- not "our customers".
- **Lead with the reader's situation**, not the product features. What are they feeling? What problem are they trying to solve?
- **Benefits over features.** "Know exactly what your body is missing" not "measures 5 biomarkers".
- **Conversational but credible.** Contractions are fine. Jargon is not.

## Email structure logic

```
HERO      → Grab attention. State the transformation promise.
BODY      → Bridge the gap: here is your problem, here is why it matters, here is the solution.
FEATURES  → Give them 3 reasons to trust the product.
CTA CARD  → Remove friction. Reduce it to one simple action.
SIGNATURE → (optional) Make it personal. A real person sent this.
```

## Headline formulas

| Formula | Example |
|---------|---------|
| "Find out [benefit]" | "Find out what your body is really missing" |
| "Your [thing] is ready" | "Your personalised formula is ready" |
| "[Number] vitamins. One answer." | "5 vitamins. One finger prick. Real answers." |
| "Why you feel [symptom]" | "Why you feel tired even when you sleep enough" |
| "Stop guessing about [topic]" | "Stop guessing about your vitamin levels" |

## Eyebrow text (the small label above the headline)

Short, specific, uppercase. Sets context before the headline lands.
Good: "Your results are in" / "Limited time offer" / "New from Custom Supplements"
Bad: "Email update" / "Newsletter" / "Hello"

## CTA label

Action verbs only. Be specific about what they get.
Good: "Order my vitamins test" / "View my formula" / "Claim my 20% off"
Bad: "Click here" / "Learn more" / "Submit"

## Body copy length

- **3 short paragraphs** is the sweet spot for conversion emails.
- Paragraph 1: the problem or trigger ("Most people don't realise...")
- Paragraph 2: the product as the solution ("The [product] measures all five...")
- Paragraph 3: the low-friction nudge ("No guessing. Just the numbers...")

## Feature box copy

Each feature = icon + 1-3 word title + 1 sentence (10-15 words max).
Pick features that answer the reader's unspoken objections:
- "Is this accurate?" → lab quality / EU compliant / certified
- "Is it worth it?" → social proof / rating / customer count
- "Is it easy?" → at-home / fast results / simple process

## Info card nudge

Restate the value in a different angle from the hero. If the hero was about discovery,
the card should be about speed or simplicity. Keep it under 2 sentences.
Good: "Your report is one test away. Get answers in 48 hours."
Bad: "Click the button below to order your vitamins test kit today."

## Subject line formulas

- Curiosity: "Your vitamin levels might be telling you something"
- Personalised: "{{first_name}}, your formula is ready"
- Benefit-first: "Know your levels in 48 hours"
- Fear of missing: "Most people don't know they're deficient"
- Direct: "The 5-vitamin test — order yours today"

Always suggest a primary subject line + 1 A/B variant.