# Asset Registry

Named URL registry for all GetTested hosted assets.
Reference assets by name in your prompt instead of pasting URLs.

Example: "create a marketing email for the Iron Test, use img-iron-test image"

---

## Logos

| Name | URL |
|------|-----|
| `logo-with-name` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/brand%2Fgettested-logo.png |
| `logo-icon-only` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1781446676583-getTested_logo_blue_150.png |

Default: always use `logo-with-name` in the email header unless the user specifies otherwise.

---

## Sender photos — Patrik Johansson

Six photo options for the signature block. Default is `sender-patrik-1`.
Ask the user which to use, or use the default if not specified.

| Name | URL |
|------|-----|
| `sender-patrik-1` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692244093-7.jpg |
| `sender-patrik-2` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692245849-2.jpg |
| `sender-patrik-3` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692245516-3.png |
| `sender-patrik-4` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692245193-4.jpg |
| `sender-patrik-5` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692244868-5.jpg |
| `sender-patrik-6` | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692244548-6.jpg |

---

## Product images

| Name | URL | Product |
|------|-----|---------|
| *(add rows as products are uploaded)* | | |

Example row format:
`img-vitamins-test` | https://your-cdn.com/vitamins-test.jpg | Vitamins Test kit

---

## Video thumbnails

| Name | YouTube Video ID | Auto-thumbnail URL | Video title |
|------|-----------------|-------------------|------------|
| *(add rows as videos are published)* | | | |

YouTube auto-thumbnail pattern:
`https://img.youtube.com/vi/VIDEO_ID/maxresdefault.jpg`

YouTube video link pattern:
`https://www.youtube.com/watch?v=VIDEO_ID`

---

## Banners

| Name | URL | Dimensions | Used for |
|------|-----|-----------|---------|
| *(add rows as banners are created)* | | | |

---

## How to add a new asset

1. Upload the image to your Supabase storage (or any public CDN)
2. Copy the public URL
3. Add a row to the relevant table above with a short `kebab-case` name
4. Repackage the skill: extract the `.skill` zip, edit this file, repackage
5. Reinstall in Claude Code

Once added, reference the asset by name in any prompt:
  "create an announcement email using img-iron-test and vid-launch-video"