# Email Sections Reference

All available HTML blocks. Pick and assemble the ones needed for the brief.
Sections slot into `<table role="presentation" class="container">` as `<tr><td>` rows.

---

## 1. Header / Logo

Always include. Keep the SVG for Custom Supplements branding.
If the user provides a different brand name and no logo, replace the SVG with:

```html
<span style="font-size:22px;font-weight:800;color:#0C8097;">{{website_name}}</span>
```

---

## 2. Hero

Always include.

```html
<tr><td class="hero">
  <p class="eyebrow">EYEBROW TEXT</p>
  <h1>HEADLINE HERE</h1>
  <p>SUBHEADLINE 1-2 sentences.</p>
  <a class="btn" href="{{cta_url}}">{{cta_label}}</a>
</td></tr>
```

Eyebrow: 2-4 words, uppercase, context-setting (e.g. "Your results are in").
Headline: 6-10 words, benefit-driven, no period.

---

## 3. Body Copy

Always include.

```html
<tr><td class="content copy">
  <p>Hi {{customer_first_name}},</p>
  <p>PARAGRAPH 1 -- the problem or trigger event.</p>
  <p>PARAGRAPH 2 -- what {{product_name}} does and why it works.</p>
  <p>PARAGRAPH 3 -- the nudge / what to do next.</p>
</td></tr>
```

Keep sentences short. 2-3 paragraphs max. Conversational but professional.

---

## 4. Feature Boxes (3-column)

Always include. Choose three: a stat, a credential, social proof, or unique mechanism.

```html
<tr><td class="section" style="padding-top:0;">
  <table role="presentation" class="feature-row"><tr>
    <td class="feature-box">
      <div class="feature-inner">
        <div class="feature-icon">ICON</div>
        <div class="feature-title">TITLE</div>
        <div class="feature-text">One sentence description.</div>
      </div>
    </td>
    <td class="feature-box">
      <div class="feature-inner">
        <div class="feature-icon">ICON</div>
        <div class="feature-title">TITLE</div>
        <div class="feature-text">One sentence description.</div>
      </div>
    </td>
    <td class="feature-box">
      <div class="feature-inner">
        <div class="feature-icon">ICON</div>
        <div class="feature-title">TITLE</div>
        <div class="feature-text">One sentence description.</div>
      </div>
    </td>
  </tr></table>
</td></tr>
```

ICON can be: a number ("5-in-1", "4.8/5"), an emoji (&#127968; = house, &#9989; = checkmark), or short text ("EU", "Lab").

---

## 5. Info Card CTA

Always include. Repeat the CTA in a highlighted card.

```html
<tr><td class="section center" style="padding-top:0;">
  <div class="info-card" style="background:linear-gradient(135deg,#e4f7fa 0%,#f6fcfd 100%); border-color:#d6eef2;">
    <p style="margin:0 0 22px; font-size:15px; line-height:1.65; color:#3f3f46;">
      1-2 sentence low-pressure nudge. Tell them what is waiting for them.
    </p>
    <a class="btn" href="{{cta_url}}">{{cta_label}}</a>
  </div>
</td></tr>
```

---

## 6. Image Block

Optional. Include when user provides a product photo, banner, or illustration.
Place after hero copy or between copy paragraphs.

```html
<tr><td class="section" style="padding-top:0; padding-bottom:0;">
  <img src="{{image_url}}"
       alt="{{product_name}}"
       width="520"
       style="display:block; width:100%; max-width:520px; border-radius:14px; margin:0 auto;" />
</td></tr>
```

Add `{{image_url}}` to the config block. If user has no URL yet, leave the placeholder.

---

## 7. Video Thumbnail Block

Optional. Include only when the user asks for a video section.
Emails cannot autoplay video -- this is a clickable thumbnail with a CSS play button.

```html
<tr><td class="section" style="padding-top:0; padding-bottom:32px;">
  <p style="margin:0 0 12px; font-size:11px; font-weight:800; letter-spacing:1.5px; text-transform:uppercase; color:#0C8097; text-align:center;">See how it works</p>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center">
      <a href="{{video_url}}" target="_blank"
         style="display:block; position:relative; text-decoration:none; max-width:520px; margin:0 auto; border-radius:14px; overflow:hidden; line-height:0; background:#d0eef5;">
        <img src="{{video_thumbnail_url}}"
             alt="Watch: How {{product_name}} works"
             width="520"
             style="display:block; width:100%; border-radius:14px;" />
        <span style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
                     display:inline-block; width:72px; height:72px; background:rgba(220,0,0,0.92);
                     border-radius:50%; text-align:center; line-height:72px; font-size:30px; color:#fff;">
          &#9654;
        </span>
      </a>
    </td></tr>
  </table>
</td></tr>
```

YouTube thumbnail URL pattern: `https://img.youtube.com/vi/VIDEO_ID/maxresdefault.jpg`
Change the label "See how it works" to match the video purpose.

---

## 8. Signature Block

Optional. Include ONLY when the user explicitly asks for a personal sender signature.
Place between the info card and the footer.

```html
<tr><td style="padding:0 40px 32px;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
         style="border-top:1px solid #f0f0f2; padding-top:28px;">
    <tr>
      <!-- Remove this <td> entirely if no sender photo URL is available -->
      <td style="vertical-align:top; padding-right:18px; width:88px;">
        <img src="{{sender_photo_url}}"
             alt="{{sender_name}}"
             width="80"
             style="display:block; width:80px; height:80px; border-radius:10px; object-fit:cover;" />
      </td>
      <td style="vertical-align:top;">
        <p style="margin:0 0 3px; font-size:15px; font-weight:800; color:#18181b;">{{sender_name}}</p>
        <p style="margin:0 0 14px; font-size:13px; font-style:italic; color:#52525b;">{{sender_title}}</p>
        <!-- Remove the paragraph below if no personal LinkedIn -->
        <p style="margin:0 0 14px; font-size:13px; color:#52525b; line-height:1.5;">
          Follow our journey through my personal
          <a href="{{sender_linkedin_personal_url}}" style="color:#0C8097;">LinkedIn here</a>.
        </p>
        <p style="margin:0; font-size:13px; color:#52525b;">Corporate links below &#128071;</p>
        <p style="margin:6px 0 0; font-size:13px; line-height:2;">
          <a href="{{social_linkedin_url}}"  style="color:#0C8097; text-decoration:none;">LinkedIn</a>
          &nbsp;|&nbsp;
          <a href="{{social_instagram_url}}" style="color:#0C8097; text-decoration:none;">Instagram</a>
          &nbsp;|&nbsp;
          <a href="{{social_facebook_url}}"  style="color:#0C8097; text-decoration:none;">Facebook</a>
          &nbsp;|&nbsp;
          <a href="{{social_youtube_url}}"   style="color:#0C8097; text-decoration:none;">YouTube</a>
          &nbsp;|&nbsp;
          <a href="{{social_website_url}}"   style="color:#0C8097; text-decoration:none;">Website</a>
        </p>
      </td>
    </tr>
  </table>
</td></tr>
```

Rules:
- Remove the photo `<td>` block if no sender photo URL is provided
- Remove individual social `<a>` tags for platforms not provided
- When a signature is present, omit the "Best regards, [Team]" line from the footer

---


---

## 9. Footer variants

Three footer styles. Use the one the user selected in Step 3.
All three always include copyright and unsubscribe.

---

### Footer A — Brand sign-off (default)

Warm brand-level close. Use when no personal signature is needed.

```html
<tr><td><hr style="border:none; border-top:1px solid #f0f0f2; margin:0;" /></td></tr>
<tr><td class="footer">
  <p>Questions? <a href="mailto:{{support_email}}">Contact us</a> — we're here to help.</p>
  <p style="margin-top:20px; color:#18181b; font-weight:700;">Best of Health,<br>{{website_name}} Team</p>
  <p style="margin-top:24px;">&copy; {{current_year}} {{website_name}}. All rights reserved.<br>
  No longer want to receive these emails? <a href="{{unsubscribe_url}}">Unsubscribe</a></p>
</td></tr>
```

---

### Footer B — Personal signature

Use when the user selects signature footer. Ask which photo (sender-patrik-1 through sender-patrik-6).
Default photo: sender-patrik-1.
Remove the photo `<td>` entirely if user has no photo.
Remove individual social links not needed.

```html
<tr><td style="padding:0 40px 32px;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
         style="border-top:1px solid #f0f0f2; padding-top:28px;">
    <tr>
      <!-- Remove this <td> if no photo -->
      <td style="vertical-align:top; padding-right:18px; width:88px;">
        <img src="SENDER_PHOTO_URL"
             alt="{{sender_name}}"
             width="80"
             style="display:block; width:80px; height:80px; border-radius:10px; object-fit:cover;" />
      </td>
      <td style="vertical-align:top;">
        <p style="margin:0 0 3px; font-size:15px; font-weight:800; color:#18181b;">{{sender_name}}</p>
        <p style="margin:0 0 14px; font-size:13px; font-style:italic; color:#52525b;">{{sender_title}}</p>
        <p style="margin:0 0 14px; font-size:13px; color:#52525b; line-height:1.5;">
          Follow our journey through my personal
          <a href="https://www.linkedin.com/in/patrikswe" style="color:#0C8097;">LinkedIn here</a>.
        </p>
        <p style="margin:0; font-size:13px; color:#52525b;">Corporate links below &#128071;</p>
        <p style="margin:6px 0 0; font-size:13px; line-height:2;">
          <a href="https://www.linkedin.com/company/gettested-io/"  style="color:#0C8097; text-decoration:none;">LinkedIn</a>
          &nbsp;|&nbsp;
          <a href="https://www.instagram.com/gettested.io" style="color:#0C8097; text-decoration:none;">Instagram</a>
          &nbsp;|&nbsp;
          <a href="https://www.facebook.com/gettested.io"  style="color:#0C8097; text-decoration:none;">Facebook</a>
          &nbsp;|&nbsp;
          <a href="https://www.youtube.com/@GetTestedYoutube"   style="color:#0C8097; text-decoration:none;">YouTube</a>
          &nbsp;|&nbsp;
          <a href="https://gettested.io"   style="color:#0C8097; text-decoration:none;">Website</a>
        </p>
      </td>
    </tr>
  </table>
</td></tr>
<tr><td><hr style="border:none; border-top:1px solid #f0f0f2; margin:0;" /></td></tr>
<tr><td class="footer">
  <p>Questions? <a href="mailto:{{support_email}}">Contact us</a> — we're here to help.</p>
  <p style="margin-top:24px;">&copy; {{current_year}} {{website_name}}. All rights reserved.<br>
  No longer want to receive these emails? <a href="{{unsubscribe_url}}">Unsubscribe</a></p>
</td></tr>
```

**Sender photo URLs (Patrik):**

| Name | URL |
|------|-----|
| sender-patrik-1 | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692244093-7.jpg |
| sender-patrik-2 | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692245849-2.jpg |
| sender-patrik-3 | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692245516-3.png |
| sender-patrik-4 | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692245193-4.jpg |
| sender-patrik-5 | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692244868-5.jpg |
| sender-patrik-6 | https://poozlsybaxhcvskysnxh.supabase.co/storage/v1/object/public/assets/email-images/e860dfe5-7fb9-410c-882a-4d2ef291dc4f/1769692244548-6.jpg |

Replace SENDER_PHOTO_URL with the URL from the table matching the user's chosen photo.

---

### Footer C — Minimal

Copyright and unsubscribe only. No sign-off. Use for transactional, re-engagement, or minimal preset.

```html
<tr><td><hr style="border:none; border-top:1px solid #f0f0f2; margin:0;" /></td></tr>
<tr><td class="footer">
  <p>&copy; {{current_year}} {{website_name}}. All rights reserved.<br>
  No longer want to receive these emails? <a href="{{unsubscribe_url}}">Unsubscribe</a></p>
</td></tr>
```
---

## Standard section order

```
Header / Logo        (always)
Hero                 (always)
Body Copy            (always)
Image Block          (optional -- after hero or mid-copy)
Video Thumbnail      (optional -- after body copy)
Feature Boxes        (always)
Info Card CTA        (always)
Signature            (optional -- before footer)
Footer               (always)
```