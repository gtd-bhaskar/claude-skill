# Email Presets

Each preset defines a named email type with a fixed section layout and tone guidance.
When the user names a preset (or describes a use case that maps to one), use that preset's
section order and defaults -- then layer in the specific content from their brief.

---

## How to detect the preset

| User says...                                            | Use preset     |
|---------------------------------------------------------|----------------|
| "marketing email", "promo email", "campaign"            | `marketing`    |
| "flow email", "automation", "sequence", "drip"          | `flow`         |
| "announcement", "launch", "new product", "news"         | `announcement` |
| "quiz result", "personalised", "formula ready"          | `quiz-result`  |
| "re-engagement", "win-back", "we miss you", "inactive"  | `re-engagement`|
| "newsletter", "update", "roundup"                       | `newsletter`   |

If the user doesn't name a preset, infer from context. Default to `marketing` when unsure.

---

## Preset: `marketing`

**Purpose:** Convert cold or warm leads on a specific product or offer.

**Sections (in order):**
1. Header / Logo
2. Hero (eyebrow + headline + subheadline + CTA button)
3. Body Copy (3 paragraphs)
4. Image Block *(optional -- include if user provides an image)*
5. Video Thumbnail *(optional -- include if user provides a video)*
6. Feature Boxes (3 columns)
7. Info Card CTA
8. Signature *(optional -- include only if explicitly requested)*
9. Footer

**Tone:** Confident, benefit-led. Stronger urgency than flow emails.
**CTA label style:** "Order my [product]", "Claim your [offer]", "Get started today"

---

## Preset: `flow`

**Purpose:** Automated sequence email (welcome series, nurture, post-purchase, onboarding).
Feels personal and conversational -- less visual than marketing emails.

**Sections (in order):**
1. Header / Logo
2. Body Copy -- no hero section; open directly with "Hi {{customer_first_name}},"
3. Single CTA Button (centred, no info card wrapper)
4. Signature *(recommended -- flow emails feel better with a personal sign-off)*
5. Footer (minimal -- just copyright + unsubscribe)

**Tone:** Warm and personal. Reads like an email from a person, not a brand.
**No feature boxes.** No info card gradient. Keep it simple.
**CTA label style:** "Take a look", "See your results", "Read the guide"

Single CTA button block (use instead of info card):
```html
<tr><td class="section center" style="padding-top:0;">
  <a class="btn" href="{{cta_url}}">{{cta_label}}</a>
</td></tr>
```

---

## Preset: `announcement`

**Purpose:** Announce a new product, feature, event, or company news.

**Sections (in order):**
1. Header / Logo
2. Hero (eyebrow = "Introducing" or "Now available"; headline = the announcement)
3. Image Block *(recommended -- product photo or event graphic)*
4. Body Copy (2 paragraphs -- what it is, why it matters)
5. Feature Boxes (3 columns -- 3 key things about the new thing)
6. Info Card CTA
7. Signature *(optional)*
8. Footer

**Tone:** Excited but credible. "We built this because..." energy.
**CTA label style:** "Explore [product name]", "See what's new", "Be first to try it"

---

## Preset: `quiz-result`

**Purpose:** Post-quiz personalised email -- tell the reader their result is ready.
This matches the original Custom Supplements template style.

**Sections (in order):**
1. Header / Logo
2. Hero (eyebrow = "Your quiz is complete"; headline = personalised result is ready)
3. Body Copy (2-3 paragraphs -- what was analysed, what it means, next step)
4. Feature Boxes (3 columns -- data points, compliance, rating)
5. Info Card CTA (low-pressure -- "Take a quick look")
6. Signature *(optional)*
7. Footer

**Tone:** Reassuring and personal. The reader did the work; now we deliver the value.
**CTA label style:** "View my results", "See my formula", "View my personal plan"

---

## Preset: `re-engagement`

**Purpose:** Win back inactive subscribers or lapsed customers.

**Sections (in order):**
1. Header / Logo
2. Hero (eyebrow = "We miss you" or "Still thinking about it?"; honest and direct headline)
3. Body Copy (2 paragraphs -- acknowledge the gap, remind them of the value, offer a reason to return)
4. Feature Boxes OR single testimonial block (social proof to rebuild trust)
5. Info Card CTA (low pressure -- "No commitment, just a look")
6. Footer (no signature -- keep it brand-level)

**Tone:** Humble, direct. No hard sell. Give them a reason, not a reason to unsubscribe.
**CTA label style:** "Come back and take a look", "See what changed", "Claim your offer"

---

## Preset: `newsletter`

**Purpose:** Regular update email -- company news, content roundup, tips.

**Sections (in order):**
1. Header / Logo
2. Hero (eyebrow = issue number or date; headline = the main topic)
3. Body Copy (2-3 sections separated by a thin `<hr>` styled divider)
4. Video Thumbnail *(optional -- link to latest video or podcast)*
5. Single CTA Button (centred -- link to full article, video, or product)
6. Signature *(recommended -- newsletters are personal)*
7. Footer

**Tone:** Informative and conversational. Like a letter from the founder.
**No feature boxes.** No hard CTA card.

Divider between newsletter sections:
```html
<tr><td style="padding:0 40px;">
  <hr style="border:none; border-top:1px solid #f0f0f2; margin:0;" />
</td></tr>
```

---

## Modifier flags

These can be combined with any preset:

| User says          | Effect                                              |
|--------------------|-----------------------------------------------------|
| "with video"       | Add Video Thumbnail block after Body Copy           |
| "with image"       | Add Image Block after Body Copy                     |
| "with signature"   | Add Signature block before Footer                   |
| "no signature"     | Omit Signature even if preset recommends it         |
| "minimal"          | Strip feature boxes and info card, keep copy + CTA  |
| "with A/B subject" | Provide two subject line options                    |