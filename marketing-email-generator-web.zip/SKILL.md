---
name: marketing-email-generator
description: >
  Generates complete, ready-to-send HTML marketing emails using a polished branded template.
  Use this skill whenever the user asks to create, write, draft, or generate a marketing email,
  flow email, drip email, announcement email, newsletter, quiz result email, re-engagement email,
  or any email campaign. Triggers on phrases like "write me an email", "create an email for",
  "draft a marketing email", "generate an HTML email", "make an email campaign", "build a flow
  email", "create an announcement", or any request where the output should be a formatted email.
  Always use this skill when an email is being created -- even if the user just says "make an email
  about X" without specifying a type, this skill should fire.
---

# Marketing Email Generator

Generate a **complete, ready-to-send HTML email file** from the user's brief.

## Step-by-step

### Step 1 — Read brand + assets
Always read these two files first:
- `references/brand.md` — pre-fills brand name, support email, social links, default sender
- `references/assets.md` — resolves asset names to hosted URLs

### Step 2 — Detect preset + modifiers
Read `references/presets.md`. Match user intent to a preset:
`marketing` · `flow` · `announcement` · `quiz-result` · `re-engagement` · `newsletter`

Also check for modifier flags: `with video` · `with image` · `with signature` · `no signature` · `minimal` · `with A/B subject`

### Step 3 — Ask clarifying questions BEFORE building

**Always ask these two questions before writing any HTML.** Do not skip them, do not assume.
Present them together in a single message so the user answers once:

---

**Question 1 — CTA URL:**
Ask for the exact URL the main button should link to.

> "What URL should the main button link to?"

If the user has already provided a URL in their brief, skip this question and use it.
Never use `{{cta_url}}` as a literal placeholder in the final HTML — always use a real URL.
If the user says "I don't have it yet" or "add it later", then and only then use `{{cta_url}}`
as a placeholder and flag it clearly in the report.

---

**Question 2 — Footer style:**
Ask which footer the user wants. Present the options clearly:

> "Which footer would you like?
>
> **A — Brand sign-off** (default)
> 'Best of Health, GetTested Team' + copyright + unsubscribe
>
> **B — Personal signature**
> Patrik's photo + name + title + LinkedIn + social links + copyright + unsubscribe
> (say which photo to use: sender-patrik-1 through sender-patrik-6, or I'll use sender-patrik-1)
>
> **C — Minimal**
> Copyright + unsubscribe only — no sign-off, no signature"

---

Once you have both answers, proceed to build.

### Step 4 — Collect remaining brief details
Read `references/sections.md`, `references/variables.md`, `references/copy-guide.md`.
Fill all other gaps with sensible defaults from brand.md.

### Step 5 — Build the email
- Config block at the top of `<body>` (only variables actually used; CTA URL filled with real value)
- Sections in the preset's defined order + modifiers applied
- Footer matching the user's chosen style (see `references/sections.md` footer variants)

### Step 6 — Write the file
Save to `gettested-[preset]-[product-slug]-email.html` in the working directory.

### Step 7 — Report back
- File path
- Preset used + modifiers applied
- Footer style used
- Suggested subject line (+ A/B variant if requested)
- Any remaining `{{variables}}` that still need real values (flag clearly)

## Gathering the Brief

Brand defaults from brand.md are pre-filled. User provides:

| Field | Notes |
|-------|-------|
| Product / service | What is being promoted |
| Preset / email type | Infer if not stated |
| CTA URL | **Always ask** — never leave as placeholder unless user confirms |
| Footer style | **Always ask** — A (brand), B (signature), or C (minimal) |
| Key copy points | What to emphasise |
| Image / video | Asset name or URL; only if modifier flag used |

## Reference files

| File | When to read |
|------|-------------|
| `references/brand.md`     | Always -- first |
| `references/assets.md`    | Always -- resolve asset names |
| `references/presets.md`   | Always -- detect email type |
| `references/sections.md`  | Always -- HTML snippets + footer variants |
| `references/variables.md` | Always -- shortcode table + config block |
| `references/copy-guide.md`| When writing copy |
| `assets/email-template.html` | Base structural template with CSS |

## Quality checklist

- [ ] Asked for CTA URL before building (not assumed or left as placeholder)
- [ ] Asked for footer style before building
- [ ] Brand defaults from brand.md applied
- [ ] Correct preset used; modifier flags applied
- [ ] Config block present; CTA URL is a real URL (not {{cta_url}} unless user confirmed)
- [ ] Footer matches chosen style
- [ ] No hardcoded non-brand URLs in HTML body
- [ ] HTML is valid and self-contained